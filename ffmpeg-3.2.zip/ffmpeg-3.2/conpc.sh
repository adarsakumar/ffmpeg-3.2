./configure --enable-pic --enable-shared --disable-static --disable-htmlpages --disable-manpages --disable-podpages --disable-txtpages --disable-debug 
